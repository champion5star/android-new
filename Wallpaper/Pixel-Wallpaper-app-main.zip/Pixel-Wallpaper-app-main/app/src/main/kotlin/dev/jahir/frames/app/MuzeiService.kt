package dev.jahir.frames.app

import dev.jahir.frames.muzei.FramesArtProvider

class MuzeiService : FramesArtProvider()