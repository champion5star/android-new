@file:Suppress("unused")

object MyApp {
    const val appId = "dev.wacko1805.pixel.wallpapers"
    const val version = 105
    const val versionName = "1.0.5"
}
