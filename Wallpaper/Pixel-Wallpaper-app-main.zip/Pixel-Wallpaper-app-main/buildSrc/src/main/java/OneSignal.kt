@file:Suppress("unused")

object OneSignal {
    const val appId = "4ebf3689-d3ab-43fc-b106-6f5debb1c9a3"
    const val googleProjectNumber = "191533712411"
}
