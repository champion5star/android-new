package com.developerdepository.wallipi.Common

object Common {
    public var categoryName: String = ""
    public var wallpaperListTitle: String = ""
}