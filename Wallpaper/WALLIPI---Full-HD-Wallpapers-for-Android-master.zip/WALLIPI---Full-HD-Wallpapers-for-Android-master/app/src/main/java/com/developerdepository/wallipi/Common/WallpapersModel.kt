package com.developerdepository.wallipi.Common

data class WallpapersModel(
    val name: String = "",
    val image: String = "",
    val thumbnail: String = ""
)